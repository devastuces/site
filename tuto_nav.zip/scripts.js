$(document).ready(function () {
  $(".nav-icon").on("click",function () {
     $(".icon1").toggleClass("trns-icon1");
     $(".icon2").toggleClass("trns-icon2");
     $(".icon3").toggleClass("trns-icon3");
     $(".full-link").slideToggle(500);
  });
   
});